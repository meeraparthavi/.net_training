﻿using System;

namespace Program3
{
    class Generic<T>
    {
        public T genericvariable1, genericvariable2;
        public void Add()
        {
            dynamic a = genericvariable1;
            dynamic b = genericvariable2;
            T Sum;
            Sum = a + b;
            Console.WriteLine(Sum);
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Generic<int> generic_int = new Generic<int>();
            generic_int.genericvariable1 = 10;
            generic_int.genericvariable2 = 20;
            Generic<string> generic_string = new Generic<string>();
            generic_string.genericvariable1 = "Hello ";
            generic_string.genericvariable2 = "World";
            generic_int.Add();
            generic_string.Add();
        }
    }
}