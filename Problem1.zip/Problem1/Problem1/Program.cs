﻿using System;

namespace Problem1
{
    class Amrita_college
    {
        public string College_name = "ACET", Address;
        public int College_code, No_of_faculties, No_of_Students;
        public Amrita_college()
        {
            Console.WriteLine("College name: Amrita College of Engineering and Technology");
            Console.WriteLine("College code: 9623");
            Console.WriteLine("Address: Nagarcoil");
            Console.WriteLine("No of faculties: 50");
            Console.WriteLine("No of Students: 550");
        }
        public void getcollege_code()
        {
            Console.WriteLine();
            Console.WriteLine("Enter College Code: ");
            College_code = Convert.ToInt32(Console.ReadLine());
        }
        public void getcollege_address()
        {
            Console.WriteLine();
            Console.WriteLine("Enter Address: ");
            Address = Console.ReadLine();
        }
        public void getcollege_strength()
        {
            Console.WriteLine();
            Console.WriteLine("Enter No. of Faculties: ");
            No_of_faculties = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter No. of students: ");
            No_of_Students = Convert.ToInt32(Console.ReadLine());
        }
        public void getcollege_detail()
        {
            Console.WriteLine("College name: {0}",College_name);
            Console.WriteLine("College code: {0}",College_code);
            Console.WriteLine("Address: {0}",Address);
            Console.WriteLine("No of faculties: {0}",No_of_faculties);
            Console.WriteLine("No of Students: {0}",No_of_Students);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("First Object");
            Amrita_college amrita_ngl_college = new Amrita_college();
            amrita_ngl_college.getcollege_code();
            amrita_ngl_college.getcollege_address();
            amrita_ngl_college.getcollege_strength();

            Console.WriteLine("Details of First object");
            amrita_ngl_college.getcollege_detail();

            Console.WriteLine();
            Console.WriteLine("Second Object");
            Amrita_college amrita_cbe_college = new Amrita_college();
            amrita_cbe_college.getcollege_address();

            Console.WriteLine("Address of second object");
            Console.WriteLine(amrita_cbe_college.Address);
        }
    }
}
